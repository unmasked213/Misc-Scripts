﻿#requires -Version 5.1
[CmdletBinding()]
param()

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$extensions = @(
    '.jpg',
    '.jpeg',
    '.jpe',
    '.jfif',
    '.png',
    '.bmp',
    '.dib',
    '.gif',
    '.tif',
    '.tiff'
)

foreach ($extension in $extensions) {
    $verbPath = "Registry::HKEY_CURRENT_USER\Software\Classes\SystemFileAssociations\$extension\shell\ExplorerImageFlip"

    if (Test-Path -Path $verbPath) {
        Remove-Item -Path $verbPath -Recurse -Force
    }
}

if (-not ('ExplorerImageFlip.UninstallShellNotify' -as [type])) {
    Add-Type -Namespace ExplorerImageFlip -Name UninstallShellNotify -MemberDefinition @'
[System.Runtime.InteropServices.DllImport("shell32.dll")]
public static extern void SHChangeNotify(
    uint eventId,
    uint flags,
    System.IntPtr item1,
    System.IntPtr item2);
'@
}

[ExplorerImageFlip.UninstallShellNotify]::SHChangeNotify(
    0x08000000,
    0,
    [IntPtr]::Zero,
    [IntPtr]::Zero)

$installDirectory = Join-Path -Path $env:LOCALAPPDATA -ChildPath 'ExplorerImageFlip'
if (Test-Path -LiteralPath $installDirectory) {
    Remove-Item -LiteralPath $installDirectory -Recurse -Force
}

Write-Host ''
Write-Host 'Removed: Flip image'
