# Explorer Image Flip

Adds this per-user Windows File Explorer menu to supported image files:

```text
Flip image
├── Flip horizontally
└── Flip vertically
```

The selected files are modified in place. One image or a multi-selection can be
processed. Successful operations are silent; failures are collected into one
Windows error dialog and written to a local log.

## Why this uses a small C# helper

The earlier Explorer image tool already contained the important part:
`JpegBitmapEncoder.FlipHorizontal`. This version adds `FlipVertical`, explicit
file arguments, context-menu activation, duplicate-invocation protection and a
safer install path.

JPEG files keep the WPF/WIC JPEG transform path instead of being sent through
FFmpeg. That avoids an ordinary decode-and-reencode generation. PNG, BMP, GIF
and TIFF are decoded, flipped and re-encoded with their corresponding WPF
lossless-format encoders.

The installer compiles the helper with Windows PowerShell 5.1 and the WPF
assemblies already present on Windows 10 and Windows 11. Python, FFmpeg, the
.NET 8 SDK and administrator rights are not required.

## Supported formats

- JPEG: `.jpg`, `.jpeg`, `.jpe`, `.jfif`
- PNG: `.png`
- BMP: `.bmp`, `.dib`
- GIF: `.gif`
- TIFF: `.tif`, `.tiff`

WebP, AVIF and HEIC are deliberately not registered. They would need a separate
codec path and could not inherit the JPEG lossless-transform guarantee.

## Install

Run:

```text
Install.cmd
```

The installer:

- compiles `ExplorerImageFlip.cs` as a windowless executable;
- installs it to `%LocalAppData%\ExplorerImageFlip`;
- registers the cascading menu under
  `HKCU\Software\Classes\SystemFileAssociations`;
- refreshes Explorer's file-association cache;
- requires no administrator rights.

The menu is registered with Windows' `Player` multi-selection model. Legacy
static verbs are available for selections of up to 100 items.

## Behaviour and safety

- The operation replaces each original file.
- A unique temporary file is created beside the original.
- The temporary output is decoded and validated before replacement.
- Replacement uses `File.Replace` where supported.
- A rollback path is used when atomic replacement is unavailable.
- One failed file does not stop the remaining selected files.
- Read-only attributes are temporarily cleared and restored.
- Explorer is notified after each successful replacement so thumbnails refresh.
- Repeated shell activations for the same selection are de-duplicated. This
  protects against Windows invoking a legacy verb more than once for one
  multi-selection.

The original tool's foreground-Explorer selection lookup remains as a context
menu fallback. It expands the batch only when that selection still contains
the file that invoked the command, so a rapid selection change cannot pull in
an unrelated batch. Explicit paths also cover desktop and single-file calls.

## Error log

Errors are appended to:

```text
%LocalAppData%\ExplorerImageFlip\ExplorerImageFlip.log
```

No log is written for successful operations.

## Uninstall

Run:

```text
Uninstall.cmd
```

This removes the registered menu entries and the installed program directory.
