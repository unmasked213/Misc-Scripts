﻿#requires -Version 5.1
[CmdletBinding()]
param()

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$sourcePath = Join-Path -Path $PSScriptRoot -ChildPath 'ExplorerImageFlip.cs'
if (-not (Test-Path -LiteralPath $sourcePath -PathType Leaf)) {
    throw "ExplorerImageFlip.cs was not found beside this installer: $sourcePath"
}

$installDirectory = Join-Path -Path $env:LOCALAPPDATA -ChildPath 'ExplorerImageFlip'
$installedSource = Join-Path -Path $installDirectory -ChildPath 'ExplorerImageFlip.cs'
$installedExecutable = Join-Path -Path $installDirectory -ChildPath 'ExplorerImageFlip.exe'
$buildExecutable = Join-Path -Path $installDirectory -ChildPath ('ExplorerImageFlip.build-' + [Guid]::NewGuid().ToString('N') + '.exe')

New-Item -ItemType Directory -Path $installDirectory -Force | Out-Null
Copy-Item -LiteralPath $sourcePath -Destination $installedSource -Force

Add-Type -AssemblyName PresentationCore
Add-Type -AssemblyName WindowsBase
Add-Type -AssemblyName Microsoft.CSharp

$referenceAssemblies = @(
    [System.Uri].Assembly.Location
    [System.Linq.Enumerable].Assembly.Location
    [Microsoft.CSharp.RuntimeBinder.Binder].Assembly.Location
    [System.Windows.DependencyObject].Assembly.Location
    [System.Windows.Media.Imaging.BitmapDecoder].Assembly.Location
) | Select-Object -Unique

try {
    Add-Type `
        -LiteralPath $installedSource `
        -ReferencedAssemblies $referenceAssemblies `
        -OutputAssembly $buildExecutable `
        -OutputType WindowsApplication

    if (-not (Test-Path -LiteralPath $buildExecutable -PathType Leaf)) {
        throw "The compiler did not create the expected executable: $buildExecutable"
    }

    if (Test-Path -LiteralPath $installedExecutable) {
        Remove-Item -LiteralPath $installedExecutable -Force
    }

    Move-Item -LiteralPath $buildExecutable -Destination $installedExecutable -Force
}
finally {
    if (Test-Path -LiteralPath $buildExecutable) {
        Remove-Item -LiteralPath $buildExecutable -Force -ErrorAction SilentlyContinue
    }
}

$extensions = @(
    '.jpg',
    '.jpeg',
    '.jpe',
    '.jfif',
    '.png',
    '.bmp',
    '.dib',
    '.gif',
    '.tif',
    '.tiff'
)

$horizontalCommand = '"' + $installedExecutable + '" horizontal --explorer-selection "%1"'
$verticalCommand = '"' + $installedExecutable + '" vertical --explorer-selection "%1"'

foreach ($extension in $extensions) {
    $verbPath = "Registry::HKEY_CURRENT_USER\Software\Classes\SystemFileAssociations\$extension\shell\ExplorerImageFlip"

    if (Test-Path -Path $verbPath) {
        Remove-Item -Path $verbPath -Recurse -Force
    }

    New-Item -Path $verbPath -Force | Out-Null
    New-ItemProperty -Path $verbPath -Name 'MUIVerb' -PropertyType String -Value 'Flip image' -Force | Out-Null
    New-ItemProperty -Path $verbPath -Name 'Icon' -PropertyType String -Value ($installedExecutable + ',0') -Force | Out-Null
    New-ItemProperty -Path $verbPath -Name 'MultiSelectModel' -PropertyType String -Value 'Player' -Force | Out-Null

    $subcommandsPath = Join-Path -Path $verbPath -ChildPath 'ExtendedSubCommandsKey\shell'
    New-Item -Path $subcommandsPath -Force | Out-Null

    $horizontalPath = Join-Path -Path $subcommandsPath -ChildPath 'Horizontal'
    New-Item -Path $horizontalPath -Force | Out-Null
    New-ItemProperty -Path $horizontalPath -Name 'MUIVerb' -PropertyType String -Value 'Flip horizontally' -Force | Out-Null
    New-ItemProperty -Path $horizontalPath -Name 'MultiSelectModel' -PropertyType String -Value 'Player' -Force | Out-Null

    $horizontalCommandPath = Join-Path -Path $horizontalPath -ChildPath 'command'
    New-Item -Path $horizontalCommandPath -Force | Out-Null
    Set-Item -Path $horizontalCommandPath -Value $horizontalCommand

    $verticalPath = Join-Path -Path $subcommandsPath -ChildPath 'Vertical'
    New-Item -Path $verticalPath -Force | Out-Null
    New-ItemProperty -Path $verticalPath -Name 'MUIVerb' -PropertyType String -Value 'Flip vertically' -Force | Out-Null
    New-ItemProperty -Path $verticalPath -Name 'MultiSelectModel' -PropertyType String -Value 'Player' -Force | Out-Null

    $verticalCommandPath = Join-Path -Path $verticalPath -ChildPath 'command'
    New-Item -Path $verticalCommandPath -Force | Out-Null
    Set-Item -Path $verticalCommandPath -Value $verticalCommand
}

if (-not ('ExplorerImageFlip.InstallShellNotify' -as [type])) {
    Add-Type -Namespace ExplorerImageFlip -Name InstallShellNotify -MemberDefinition @'
[System.Runtime.InteropServices.DllImport("shell32.dll")]
public static extern void SHChangeNotify(
    uint eventId,
    uint flags,
    System.IntPtr item1,
    System.IntPtr item2);
'@
}

[ExplorerImageFlip.InstallShellNotify]::SHChangeNotify(
    0x08000000,
    0,
    [IntPtr]::Zero,
    [IntPtr]::Zero)

Write-Host ''
Write-Host 'Installed: Flip image'
Write-Host "Program:   $installedExecutable"
Write-Host 'Scope:     current user only; no administrator rights required'
Write-Host 'Menus:     Flip image > Flip horizontally / Flip vertically'
Write-Host 'Formats:   JPEG, PNG, BMP, GIF and TIFF'
